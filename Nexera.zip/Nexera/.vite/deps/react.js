import {
  require_react
} from "./chunk-3A6WRQ5K.js";
export default require_react();
